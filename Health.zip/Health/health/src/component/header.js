import React from 'react';

class HeaderTitle extends React.Component {

    render() {
        return (
            <div className="header">
                
            </div>
        );
    }
}

export default HeaderTitle;