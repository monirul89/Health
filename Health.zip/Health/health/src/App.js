import React, { Component } from 'react';
import './App.css';
import HeaderTitle from './component/header';

class App extends Component {
  render() {
    return (
      <div className="App">
        <HeaderTitle />
      </div>
    );
  }
}

export default App;
